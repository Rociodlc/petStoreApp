public class petSoreApp {

    public static void main(String[]args) {
        bird bird1 = new bird(species" bird", )

    }
}
